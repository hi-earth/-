#ifndef HELI_H
#define HELI_H


class heli
{
private:
    int x,y,w,h;
public:
    heli(int a,int b,int c,int d);

    void move(int,int,int);
    int getx();
    int gamecheck(int,int);
};

#endif // HELI_H
