#include "platypus.h"

#include <QTimer>
#include <QDebug>

platypus::platypus(int a,int b,int c,int d)
{
    x=a;
    y=b;
    w=c;
    h=d;
}


int platypus::gety()
{
    return y;
}
int platypus::geth()
{
    return h;
}
void platypus::givey(int gy)
{
    y = gy;
}
void platypus::giveh(int gh)
{
    h = gh;
}

void platypus::walk()
{

}

void platypus::jump()
{
    qDebug() << "jump";
    y = y-(h*3/4);
}

void platypus::doublejump()
{
    qDebug() << "doublejump";
    y = y-(h*2/3);
}

void platypus::slide(int s)
{
    qDebug() << "slide";
    y = s;
    h = h*3/5;
}

void platypus::isjump(int i)
{
    ifjump = i;
}

void platypus::isslide(int i)
{
   ifslide = i;
}

int platypus::isjump()
{
    return ifjump;
}
int platypus::isslide()
{
    return ifslide;
}
