#ifndef PLATYPUS_H
#define PLATYPUS_H

class platypus
{
private:
    int x,y,w,h;
    bool ifjump;
    bool ifslide;
public:
    platypus(int,int,int,int);
    void jump();
    void doublejump();
    void slide(int);
    void walk();

    void isjump(int);
    void isslide(int);

    int isjump();
    int isslide();

    int gety();
    int geth();

    void givey(int);
    void giveh(int);
};

#endif // PLATYPUS_H
