#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "widget.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("PERRY THE PLATYPUS");
    ui->label_2->setGeometry(0,0,width(),height());
    QPixmap qpm(":/new/prefix1/welcome.png");
       ui->label_2->setPixmap(qpm);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_2_clicked()
{
    MainWindow::close();
}

void MainWindow::on_pushButton_clicked()
{
    w.gameStart();
    this->hide();
     w.show();
}
