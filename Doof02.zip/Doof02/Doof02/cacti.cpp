#include "cacti.h"


cactus::cactus(int a,int b,int c,int d)
{
    x=a;
    y=b;
    w=c;
    h=d;
}


void cactus::move(int t,int x1,int x2)
{
   x -= t;
   if(x<x1)x = x+x2;
}

int cactus::gamecheck(int px, int py)
{
    if(x<px+(w/30)&&x>px-(w/30)){
        if(py+(h/4)>y)
                return 1;
        else return 0;
    }
    else return 0;
}

int cactus::getx()
{
    return x;
}

