#include "dodo.h"
#include <QDebug>

dodo::dodo(int a,int b,int c,int d)
{
    x=a;
    y=b;
    w=c;
    h=d;
}
void dodo::move(int t,int x1,int x2)
{
   x -= t;
   if(x<x1)x = x+x2;

}

int dodo::getx()
{
    return x;
}

int dodo::gamecheck(int px, int py)
{
    if(x<(px +(w*11/20))&&x>(px+(w/20))){
        if((py+(h*9/10))>y)
                return 1;
                else return 0;
    }
    else return 0;
    }
