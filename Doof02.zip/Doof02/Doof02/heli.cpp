#include "heli.h"
#include <QDebug>

heli::heli(int a,int b,int c,int d)
{
    x=a;
    y=b;
    w=c;
    h=d;
}
void heli::move(int t,int x1,int x2)
{
   x -= t;
   if(x<x1)x = x+x2;

}
int heli::getx()
{
    return x;
}

int heli::gamecheck(int px, int py)
{
    if(x<(px +(w*11/20))&&x>(px+(w/20))){
        if(py<y +(h/2)){
                return 1;}
                else return 0;
    }
    else return 0;
    }
