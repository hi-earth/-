#include "road.h"

road::road(int a)
{
x = a;
}

void road::move(int t,int x1,int x2)
{
    x -= t;
    if(x<x1)x = x+x2;
}

int road::getx()
{
    return x;
}
