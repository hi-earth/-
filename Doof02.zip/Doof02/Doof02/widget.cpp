#include "widget.h"
#include "ui_widget.h"
#include <QPainter>
#include <QTimer>
#include <QTime>
#include <QDebug>
#include <QKeyEvent>


#include "cacti.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    Widget::gameStart();
}

void Widget::gameStart()
{
    isgameover(0);
    score = 0;
    speed = 50;

    d1 = new dodo(width()*100/100,height()*60/100,width()*20/100,height()*20/100);
    d2 = new dodo(width()*165/100,height()*60/100,width()*20/100,height()*20/100);
    d3 = new dodo(width()*325/100,height()*60/100,width()*20/100,height()*20/100);
    d4 = new dodo(width()*375/100,height()*60/100,width()*20/100,height()*20/100);
    d5 = new dodo(width()*575/100,height()*60/100,width()*20/100,height()*20/100);
    d6 = new dodo(width()*650/100,height()*60/100,width()*20/100,height()*20/100);
    d7 = new dodo(width()*750/100,height()*60/100,width()*20/100,height()*20/100);
    d8 = new dodo(width()*800/100,height()*60/100,width()*20/100,height()*20/100);
    d9 = new dodo(width()*925/100,height()*60/100,width()*20/100,height()*20/100);

    h1 = new heli(width()*225/100,height()*40/100,width()*20/100,height()*20/100);
    h2 = new heli(width()*275/100,height()*40/100,width()*20/100,height()*20/100);
    h3 = new heli(width()*450/100,height()*40/100,width()*20/100,height()*20/100);
    h4 = new heli(width()*475/100,height()*40/100,width()*20/100,height()*20/100);
    h5 = new heli(width()*725/100,height()*40/100,width()*20/100,height()*20/100);
    h6 = new heli(width()*775/100,height()*40/100,width()*20/100,height()*20/100);
    h7 = new heli(width()*825/100,height()*40/100,width()*20/100,height()*20/100);
    h8 = new heli(width()*875/100,height()*40/100,width()*20/100,height()*20/100);

    r1 = new road(0);
    r2 = new road(width());

    perry = new platypus(width()*10/100,height()*45/100,width()*18/100,height()*30/100);

    QTimer *timer = new QTimer(this);
    connect(timer,&QTimer::timeout,this,&Widget::timerUpdate);
    timer->start(speed);
}


Widget::~Widget()
{
    delete ui;

}


void Widget::timerUpdate()
{
    if(isgameover() != 1) {
        score = score + 15;
        ui->label->setNum(score);

    d1->move(width()/50,width()*(-1),width()*10);
    d2->move(width()/50,width()*(-1),width()*10);
    d3->move(width()/50,width()*(-1),width()*10);
    d4->move(width()/50,width()*(-1),width()*10);
    d5->move(width()/50,width()*(-1),width()*10);
    d6->move(width()/50,width()*(-1),width()*10);
    d7->move(width()/50,width()*(-1),width()*10);
    d8->move(width()/50,width()*(-1),width()*10);
    d9->move(width()/50,width()*(-1),width()*10);

    h1->move(width()/50,width()*(-1),width()*10);
    h2->move(width()/50,width()*(-1),width()*10);
    h3->move(width()/50,width()*(-1),width()*10);
    h4->move(width()/50,width()*(-1),width()*10);
    h5->move(width()/50,width()*(-1),width()*10);
    h6->move(width()/50,width()*(-1),width()*10);
    h7->move(width()/50,width()*(-1),width()*10);
    h8->move(width()/50,width()*(-1),width()*10);

    r1->move(width()/50,width()*(-1),width()*2);
    r2->move(width()/50,width()*(-1),width()*2);

    gamecheck();
    update();
    }
}

void Widget::paintEvent(QPaintEvent *event)
{
    QPainter p(this);
    p.drawPixmap(0,0,width(),height(),QPixmap("../image/background.png"));
    p.drawPixmap(r1->getx(),0,width(),height(),QPixmap("../image/road.png"));
    p.drawPixmap(r2->getx(),0,width(),height(),QPixmap("../image/road.png"));


   if(perry->isslide() == 1)
   {
       QTime time = QTime::currentTime();
       if((time.msec()%500)<125)
           p.drawPixmap(width()*6/100,height()*60/100,width()*26/100,perry->geth(),QPixmap("../image/PS01.png"));
       else if((time.msec()%500)<250)
           p.drawPixmap(width()*6/100,height()*60/100,width()*26/100,perry->geth(),QPixmap("../image/PS02.png"));
       else if((time.msec()%500)<375)
           p.drawPixmap(width()*6/100,height()*60/100,width()*26/100,perry->geth(),QPixmap("../image/PS03.png"));
       else
           p.drawPixmap(width()*6/100,height()*60/100,width()*26/100,perry->geth(),QPixmap("../image/PS04.png"));
   }
   else if(perry->isjump() == 1)
       p.drawPixmap(width()*10/100,perry->gety(),width()*18/100,perry->geth(),QPixmap("../image/perryJ.png"));
   else
       {
       QTime time = QTime::currentTime();
       if((time.msec()%500)<100)
           p.drawPixmap(width()*10/100,perry->gety(),width()*20/100,perry->geth(),QPixmap("../image/PW01.png"));
       else if((time.msec()%500)<200)
           p.drawPixmap(width()*10/100,perry->gety(),width()*20/100,perry->geth(),QPixmap("../image/PW02.png"));
       else if((time.msec()%500)<300)
           p.drawPixmap(width()*10/100,perry->gety(),width()*20/100,perry->geth(),QPixmap("../image/PW03.png"));
       else if((time.msec()%500)<400)
           p.drawPixmap(width()*10/100,perry->gety(),width()*20/100,perry->geth(),QPixmap("../image/PW04.png"));
       else
           p.drawPixmap(width()*10/100,perry->gety(),width()*20/100,perry->geth(),QPixmap("../image/PW05.png"));
   }

    if(d1->getx()>-1*width()&&d1->getx()<width())
    p.drawPixmap(d1->getx(),height()*60/100,width()*20/100,height()*20/100,QPixmap("../image/dodo.png"));
    if(d2->getx()>-1*width()&&d2->getx()<width())
    p.drawPixmap(d2->getx(),height()*60/100,width()*20/100,height()*20/100,QPixmap("../image/dodo.png"));
    if(d3->getx()>-1*width()&&d3->getx()<width())
    p.drawPixmap(d3->getx(),height()*60/100,width()*20/100,height()*20/100,QPixmap("../image/dodo.png"));
    if(d4->getx()>-1*width()&&d4->getx()<width())
    p.drawPixmap(d4->getx(),height()*60/100,width()*20/100,height()*20/100,QPixmap("../image/dodo.png"));
    if(d5->getx()>-1*width()&&d5->getx()<width())
    p.drawPixmap(d5->getx(),height()*60/100,width()*20/100,height()*20/100,QPixmap("../image/dodo.png"));
    if(d6->getx()>-1*width()&&d6->getx()<width())
    p.drawPixmap(d6->getx(),height()*60/100,width()*20/100,height()*20/100,QPixmap("../image/dodo.png"));
    if(d7->getx()>-1*width()&&d7->getx()<width())
    p.drawPixmap(d7->getx(),height()*60/100,width()*20/100,height()*20/100,QPixmap("../image/dodo.png"));
    if(d8->getx()>-1*width()&&d8->getx()<width())
    p.drawPixmap(d8->getx(),height()*60/100,width()*20/100,height()*20/100,QPixmap("../image/dodo.png"));
    if(d9->getx()>-1*width()&&d9->getx()<width())
    p.drawPixmap(d9->getx(),height()*60/100,width()*20/100,height()*20/100,QPixmap("../image/dodo.png"));

    if(h1->getx()>-1*width()&&h1->getx()<width())
    p.drawPixmap(h1->getx(),height()*40/100,width()*20/100,height()*20/100,QPixmap("../image/heli.png"));
    if(h2->getx()>-1*width()&&h2->getx()<width())
    p.drawPixmap(h2->getx(),height()*40/100,width()*20/100,height()*20/100,QPixmap("../image/heli.png"));
    if(h3->getx()>-1*width()&&h3->getx()<width())
    p.drawPixmap(h3->getx(),height()*40/100,width()*20/100,height()*20/100,QPixmap("../image/heli.png"));
    if(h4->getx()>-1*width()&&h4->getx()<width())
    p.drawPixmap(h4->getx(),height()*40/100,width()*20/100,height()*20/100,QPixmap("../image/heli.png"));
    if(h5->getx()>-1*width()&&h5->getx()<width())
    p.drawPixmap(h5->getx(),height()*40/100,width()*20/100,height()*20/100,QPixmap("../image/heli.png"));
    if(h6->getx()>-1*width()&&h6->getx()<width())
    p.drawPixmap(h6->getx(),height()*40/100,width()*20/100,height()*20/100,QPixmap("../image/heli.png"));
    if(h7->getx()>-1*width()&&h7->getx()<width())
    p.drawPixmap(h7->getx(),height()*40/100,width()*20/100,height()*20/100,QPixmap("../image/heli.png"));
    if(h8->getx()>-1*width()&&h8->getx()<width())
    p.drawPixmap(h8->getx(),height()*40/100,width()*20/100,height()*20/100,QPixmap("../image/heli.png"));

    if(Widget::isgameover() == 1)
        p.drawPixmap(width()*(-1)/10,0,width()*6/5,height(),QPixmap("../image/over.png"));

}

void Widget::keyPressEvent(QKeyEvent *event)
{
    if(event->key() == Qt::Key_Up)
            {
        qDebug() << "Key_Up is pressed";
            if(perry->isjump() == 0)
               {
                perry->isjump(1);
                perry->jump();

               QTimer *jumptimer = new QTimer(this) ;
               connect(jumptimer,&QTimer::timeout,
                       [=]()
               {
                if(perry->isjump() == 1){Widget::recover();
                    qDebug()<<"singlejump";
                jumptimer->stop();}
                else jumptimer->stop();
               });
               jumptimer->start(1000);
                }}

        else if (event->key() == Qt::Key_Down) {
         qDebug() << "Key_Down is pressed";
         if(perry->isjump() == 0)
          {perry->isslide(1);
          perry->slide(height()*60/100);}
        }
         else if (event->key() == Qt::Key_R) {
            qDebug() << "Key_R";
            Widget::gameStart();
        }

    else QWidget::keyPressEvent(event);
}

void Widget::keyReleaseEvent(QKeyEvent *event)
{

    if(event->key() == Qt::Key_Down)
    {
        if(perry->isslide() == 1)
        Widget::recover();
        qDebug() << "KeyDown is released";
    }
}


void Widget::recover()
{
    qDebug() << "recover";
    perry->givey(height()*45/100) ;
    perry->giveh(height()*30/100) ;
    perry->isslide(0);
    perry->isjump(0);

}

void Widget::gamecheck()
{
   int gc = d1->gamecheck(width()/10,perry->gety())
           +d2->gamecheck(width()/10,perry->gety())
           +d3->gamecheck(width()/10,perry->gety())
           +d4->gamecheck(width()/10,perry->gety())
           +d5->gamecheck(width()/10,perry->gety())
           +d6->gamecheck(width()/10,perry->gety())
           +d7->gamecheck(width()/10,perry->gety())
           +d8->gamecheck(width()/10,perry->gety())
           +d9->gamecheck(width()/10,perry->gety())
           +h1->gamecheck(width()/10,perry->gety())
           +h2->gamecheck(width()/10,perry->gety())
           +h3->gamecheck(width()/10,perry->gety())
           +h4->gamecheck(width()/10,perry->gety())
           +h5->gamecheck(width()/10,perry->gety())
           +h6->gamecheck(width()/10,perry->gety())
           +h7->gamecheck(width()/10,perry->gety())
           +h8->gamecheck(width()/10,perry->gety());


   if(gc == 1)gameOver();
   if(score > 500)speed = 30;
   if(score > 1000)speed = 20;
   if(score > 1500)speed = 10;
}

void Widget::gameOver()
{
    qDebug()<<"Game Over"<<score;
   isgameover(1);
// Widget::~Widget();
}

void Widget::isgameover(int i)
{
    igo = i;
}
int Widget::isgameover()
{
    return igo;
}

