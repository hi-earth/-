#ifndef COIN_H
#define COIN_H


class coin
{
private:
    int x,y;
public:
    coin(int,int);
    int getx();
    int gety();
};

#endif // COIN_H
