#ifndef ROAD_H
#define ROAD_H


class road
{
    int x;
public:
    road(int);
    void move(int,int,int);
    int getx();
};

#endif // ROAD_H
