#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>

#include <QTimer>

#include "dodo.h"
#include "heli.h"
#include "road.h"
#include "platypus.h"

namespace Ui {
class Widget;
}

class QSoundEffect;

class Widget : public QWidget
{
    Q_OBJECT

public:

    explicit Widget(QWidget *parent = nullptr);
    ~Widget();
    void gameStart();
    void gameOver();
    void gamecheck();
    void recover();

    void isgameover(int);
    int isgameover();

protected:
    void paintEvent(QPaintEvent *);
    void keyPressEvent(QKeyEvent *event);
    void keyReleaseEvent(QKeyEvent *event);


private slots:
    void on_label_linkActivated(const QString &link);

    void on_label_customContextMenuRequested(const QPoint &pos);

private:
    Ui::Widget *ui;
    void timerUpdate();
    QTimer *timer;

    dodo *d1;
    dodo *d2;
    dodo *d3;
    dodo *d4;
    dodo *d5;
    dodo *d6;
    dodo *d7;
    dodo *d8;
    dodo *d9;

    heli *h1;
    heli *h2;
    heli *h3;
    heli *h4;
    heli *h5;
    heli *h6;
    heli *h7;
    heli *h8;

    platypus *perry;
    road *r1;
    road *r2;

    int igo;
    int score;
    int speed;
};

#endif // WIDGET_H
