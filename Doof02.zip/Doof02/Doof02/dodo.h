#ifndef DODO_H
#define DODO_H


class dodo
{
private:
    int x,y,w,h;
public:
    dodo(int a,int b,int c,int d);

    void move(int,int,int);
    int gamecheck(int,int);
    int getx();
};



#endif // DODO_H
