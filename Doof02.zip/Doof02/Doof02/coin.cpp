#include "coin.h"

coin::coin(int a,int b)
{
    x = a;
    y = b;

}
