#ifndef CACTI_H
#define CACTI_H

class cactus
{
private:
    int x,y,w,h;
public:
    cactus(int a,int b,int c,int d);

    void move(int,int,int);
    int gamecheck(int,int);
    int getx();
};


#endif // CACTI_H
